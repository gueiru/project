-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ucardtest
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `basic`
--

DROP TABLE IF EXISTS `basic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `basic` (
  `bank` varchar(3) NOT NULL,
  `category` varchar(3) NOT NULL,
  `id` varchar(3) NOT NULL COMMENT '卡片ID',
  `back` float NOT NULL COMMENT '回饋金額',
  `kind` varchar(500) NOT NULL COMMENT '種類',
  `term` varchar(45) DEFAULT NULL COMMENT '條件',
  `note` varchar(100) DEFAULT NULL COMMENT '備註'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='長期活動';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic`
--

LOCK TABLES `basic` WRITE;
/*!40000 ALTER TABLE `basic` DISABLE KEYS */;
INSERT INTO `basic` VALUES ('013','0','101',0.003,'LinePay',NULL,'nan'),('013','0','101',0.03,'蝦皮購物、momo購物網、PChome線上購物、Yahoo奇摩購物中心、小樹購、Amazon、淘寶/天貓',NULL,'nan'),('013','0','101',0.03,'Apple_Store、Apple_Music、iCloud\nGoogle Play\nDisney+\nNetflix\nSpotify\nKKBOX\nKKTV',NULL,'nan'),('013','0','102',0.003,'LinePay',NULL,'nan'),('013','0','102',0.03,'\n遠東SOGO百貨\n太平洋百貨\n新光三越\nSKM Park\n遠東百貨\nBig City遠東巨城購物中心\n微風廣場\n誠品生活\n環球購物中心\nCITYLINK\nBELLAVITA\n統一時代\n台北101\nATT 4 FUN\n明曜百貨\n京站\n美麗華\n大葉高島屋\n遠企購物中心\n比漾廣場\n大江國際購物中心\n中友百貨\n廣三SOGO\nTiger City\n勤美誠品綠園道\n金典綠園道\n大魯閣新時代\n耐斯廣場\n南紡購物中心\n德安百貨\n夢時代\n大立百貨\n大統百貨\n漢神百貨\n漢神巨蛋\nMITSUI OUTLET PARK(林口、台中港、台南)\nMitsui Shopping Park LaLaport(台中)\n禮客\n義大世界購物廣場\n華泰名品城\n義享天地\n麗寶OUTLET Mall\n麗寶百貨廣場\n秀泰生活\n徐匯廣場\n台茂購物中心\n桃園統領百貨\n新月廣場\n日曜天地\n三創生活\n6+Plaza廣場\niFG遠雄廣場\n台南FOCUS\n悅誠廣場\n欣欣百貨\n宏匯廣場\n高雄棧貳庫商場\n樂購廣場\nNOKE忠泰樂生活\n昇恆昌',NULL,'nan'),('013','0','102',0.03,'\nUber Eats\nfoodpanda\nfoodomo\ninline\nEZTABLE',NULL,'nan'),('013','0','102',0.03,'餐飲',NULL,'nan'),('013','0','102',0.03,'\n康是美\n寶雅\n屈臣氏\n日藥本舖\nTomod\'s\n松本清',NULL,'nan'),('013','0','103',0.003,'LinePay',NULL,'nan'),('013','0','103',0.03,'\nUber\nLINE TAXI\nyoxi\n台灣大車隊\n大都會計程車 \n和運租車\niRent\n格上租車\n中租租車\nAVIS租車 中華 長榮 德安 華信 虎航 立榮 星宇',NULL,'nan'),('013','0','103',0.03,'民宿、青年旅館、連鎖飯店、\nKKday\nAgoda\nKLOOK\nAirbnb\nHotels.com\nExpedia\nBooking.com\nTrip.com\nAsiaYo',NULL,'nan'),('013','0','103',0.03,'\nezTravel易遊網\n雄獅旅遊(旅天下聯合國際旅行社(原雙獅聯合國際旅行社))\n可樂旅遊\n東南旅遊\n五福旅遊\n燦星旅遊\n山富旅遊\n長汎假期\n鳳凰旅行社\nEzfly易飛網\n理想旅遊\n永利旅行社\n三賀旅行社',NULL,'nan'),('013','0','104',0.003,'LinePay',NULL,'nan'),('013','0','104',0.03,'家樂福',NULL,'nan'),('013','0','104',0.03,'台灣中油-直營店',NULL,'nan'),('013','0','104',0.03,'台灣高鐵、 城市車旅\n嘟嘟房',NULL,'nan'),('013','0','104',0.03,'7-ELEVEN 全家便利商店',NULL,'nan'),('013','0','104',0.03,'全聯福利中心',NULL,'nan'),('013','0','104',0.03,'麥當勞、星巴克',NULL,'nan'),('013','0','104',0.03,'foodomo',NULL,'nan'),('013','0','104',0.03,'遠東SOGO百貨',NULL,'nan'),('013','0','104',0.03,'博客來',NULL,'nan'),('013','0','104',0.03,'OPEN錢包',NULL,'nan'),('013','0','105',0.003,'LinePay',NULL,'nan'),('013','0','105',0.035,'遠東SOGO百貨 太平洋百貨 廣三SOGO',NULL,'11-12月壽星'),('013','0','105',0.035,'民宿、青年旅館、連鎖飯店',NULL,'nan'),('013','0','105',0.1,'茹絲葵經典牛排館台灣(Ruth\'s Chris Steak House)\nUmai屋馬燒肉\nsolo pasta 義大利麵\n俺達の肉屋 日本和牛專門店\n鹽之華法式餐廳Fleur de Sel Restaurant\n廚房有雞花雕雞\n碳佐麻里精品燒肉\n与玥樓頂級粵菜餐廳\nRAW\n山海樓\n金蓬萊遵古台菜餐廳\n老新台菜',NULL,'nan'),('013','0','105',0.1,'國賓影城\n威秀影城\nShowTimes 秀泰影城',NULL,'nan'),('013','0','105',0.1,'錢櫃KTV\n好樂迪KTV\n星聚點KTV\n享溫馨KTV',NULL,'nan'),('013','1','101',0.003,'LinePay',NULL,'nan'),('013','1','101',0.03,'蝦皮購物、momo購物網、PChome線上購物、Yahoo奇摩購物中心、小樹購、Amazon、淘寶/天貓',NULL,'nan'),('013','1','101',0.03,'Apple_Store、Apple_Music、iCloud\nGoogle Play\nDisney+\nNetflix\nSpotify\nKKBOX\nKKTV',NULL,'nan'),('013','1','102',0.003,'LinePay',NULL,'nan'),('013','1','102',0.03,'\n遠東SOGO百貨\n太平洋百貨\n新光三越\nSKM Park\n遠東百貨\nBig City遠東巨城購物中心\n微風廣場\n誠品生活\n環球購物中心\nCITYLINK\nBELLAVITA\n統一時代\n台北101\nATT 4 FUN\n明曜百貨\n京站\n美麗華\n大葉高島屋\n遠企購物中心\n比漾廣場\n大江國際購物中心\n中友百貨\n廣三SOGO\nTiger City\n勤美誠品綠園道\n金典綠園道\n大魯閣新時代\n耐斯廣場\n南紡購物中心\n德安百貨\n夢時代\n大立百貨\n大統百貨\n漢神百貨\n漢神巨蛋\nMITSUI OUTLET PARK(林口、台中港、台南)\nMitsui Shopping Park LaLaport(台中)\n禮客\n義大世界購物廣場\n華泰名品城\n義享天地\n麗寶OUTLET Mall\n麗寶百貨廣場\n秀泰生活\n徐匯廣場\n台茂購物中心\n桃園統領百貨\n新月廣場\n日曜天地\n三創生活\n6+Plaza廣場\niFG遠雄廣場\n台南FOCUS\n悅誠廣場\n欣欣百貨\n宏匯廣場\n高雄棧貳庫商場\n樂購廣場\nNOKE忠泰樂生活\n昇恆昌',NULL,'nan'),('013','1','102',0.03,'\nUber Eats\nfoodpanda\nfoodomo\ninline\nEZTABLE',NULL,'nan'),('013','1','102',0.03,'餐飲',NULL,'nan'),('013','1','102',0.03,'\n康是美\n寶雅\n屈臣氏\n日藥本舖\nTomod\'s\n松本清',NULL,'nan'),('013','1','103',0.003,'LinePay',NULL,'nan'),('013','1','103',0.03,'\nUber\nLINE TAXI\nyoxi\n台灣大車隊\n大都會計程車 \n和運租車\niRent\n格上租車\n中租租車\nAVIS租車 中華 長榮 德安 華信 虎航 立榮 星宇',NULL,'nan'),('013','1','103',0.03,'民宿、青年旅館、連鎖飯店、\nKKday\nAgoda\nKLOOK\nAirbnb\nHotels.com\nExpedia\nBooking.com\nTrip.com\nAsiaYo',NULL,'nan'),('013','1','103',0.03,'\nezTravel易遊網\n雄獅旅遊(旅天下聯合國際旅行社(原雙獅聯合國際旅行社))\n可樂旅遊\n東南旅遊\n五福旅遊\n燦星旅遊\n山富旅遊\n長汎假期\n鳳凰旅行社\nEzfly易飛網\n理想旅遊\n永利旅行社\n三賀旅行社',NULL,'nan'),('013','1','104',0.003,'LinePay',NULL,'nan'),('013','1','104',0.03,'家樂福',NULL,'nan'),('013','1','104',0.03,'台灣中油-直營店',NULL,'nan'),('013','1','104',0.03,'台灣高鐵、 城市車旅\n嘟嘟房',NULL,'nan'),('013','1','104',0.03,'7-ELEVEN 全家便利商店',NULL,'nan'),('013','1','104',0.03,'全聯福利中心',NULL,'nan'),('013','1','104',0.03,'麥當勞、星巴克',NULL,'nan'),('013','1','104',0.03,'foodomo',NULL,'nan'),('013','1','104',0.03,'遠東SOGO百貨',NULL,'nan'),('013','1','104',0.03,'博客來',NULL,'nan'),('013','1','104',0.03,'OPEN錢包',NULL,'nan'),('013','1','105',0.003,'LinePay',NULL,'nan'),('013','1','105',0.035,'遠東SOGO百貨 太平洋百貨 廣三SOGO',NULL,'11-12月壽星'),('013','1','105',0.035,'民宿、青年旅館、連鎖飯店',NULL,'nan'),('013','1','105',0.1,'茹絲葵經典牛排館台灣(Ruth\'s Chris Steak House)\nUmai屋馬燒肉\nsolo pasta 義大利麵\n俺達の肉屋 日本和牛專門店\n鹽之華法式餐廳Fleur de Sel Restaurant\n廚房有雞花雕雞\n碳佐麻里精品燒肉\n与玥樓頂級粵菜餐廳\nRAW\n山海樓\n金蓬萊遵古台菜餐廳\n老新台菜',NULL,'nan'),('013','1','105',0.1,'國賓影城\n威秀影城\nShowTimes 秀泰影城',NULL,'nan'),('013','1','105',0.1,'錢櫃KTV\n好樂迪KTV\n星聚點KTV\n享溫馨KTV',NULL,'nan'),('013','2','101',0.003,'LinePay',NULL,'nan'),('013','2','101',0.03,'蝦皮購物、momo購物網、PChome線上購物、Yahoo奇摩購物中心、小樹購、Amazon、淘寶/天貓',NULL,'nan'),('013','2','101',0.03,'Apple_Store、Apple_Music、iCloud\nGoogle Play\nDisney+\nNetflix\nSpotify\nKKBOX\nKKTV',NULL,'nan'),('013','2','102',0.003,'LinePay',NULL,'nan'),('013','2','102',0.03,'\n遠東SOGO百貨\n太平洋百貨\n新光三越\nSKM Park\n遠東百貨\nBig City遠東巨城購物中心\n微風廣場\n誠品生活\n環球購物中心\nCITYLINK\nBELLAVITA\n統一時代\n台北101\nATT 4 FUN\n明曜百貨\n京站\n美麗華\n大葉高島屋\n遠企購物中心\n比漾廣場\n大江國際購物中心\n中友百貨\n廣三SOGO\nTiger City\n勤美誠品綠園道\n金典綠園道\n大魯閣新時代\n耐斯廣場\n南紡購物中心\n德安百貨\n夢時代\n大立百貨\n大統百貨\n漢神百貨\n漢神巨蛋\nMITSUI OUTLET PARK(林口、台中港、台南)\nMitsui Shopping Park LaLaport(台中)\n禮客\n義大世界購物廣場\n華泰名品城\n義享天地\n麗寶OUTLET Mall\n麗寶百貨廣場\n秀泰生活\n徐匯廣場\n台茂購物中心\n桃園統領百貨\n新月廣場\n日曜天地\n三創生活\n6+Plaza廣場\niFG遠雄廣場\n台南FOCUS\n悅誠廣場\n欣欣百貨\n宏匯廣場\n高雄棧貳庫商場\n樂購廣場\nNOKE忠泰樂生活\n昇恆昌',NULL,'nan'),('013','2','102',0.03,'\nUber Eats\nfoodpanda\nfoodomo\ninline\nEZTABLE',NULL,'nan'),('013','2','102',0.03,'餐飲',NULL,'nan'),('013','2','102',0.03,'\n康是美\n寶雅\n屈臣氏\n日藥本舖\nTomod\'s\n松本清',NULL,'nan'),('013','2','103',0.003,'LinePay',NULL,'nan'),('013','2','103',0.03,'\nUber\nLINE TAXI\nyoxi\n台灣大車隊\n大都會計程車 \n和運租車\niRent\n格上租車\n中租租車\nAVIS租車 中華 長榮 德安 華信 虎航 立榮 星宇',NULL,'nan'),('013','2','103',0.03,'民宿、青年旅館、連鎖飯店、\nKKday\nAgoda\nKLOOK\nAirbnb\nHotels.com\nExpedia\nBooking.com\nTrip.com\nAsiaYo',NULL,'nan'),('013','2','103',0.03,'\nezTravel易遊網\n雄獅旅遊(旅天下聯合國際旅行社(原雙獅聯合國際旅行社))\n可樂旅遊\n東南旅遊\n五福旅遊\n燦星旅遊\n山富旅遊\n長汎假期\n鳳凰旅行社\nEzfly易飛網\n理想旅遊\n永利旅行社\n三賀旅行社',NULL,'nan'),('013','2','104',0.003,'LinePay',NULL,'nan'),('013','2','104',0.03,'家樂福',NULL,'nan'),('013','2','104',0.03,'台灣中油-直營店',NULL,'nan'),('013','2','104',0.03,'台灣高鐵、 城市車旅\n嘟嘟房',NULL,'nan'),('013','2','104',0.03,'7-ELEVEN 全家便利商店',NULL,'nan'),('013','2','104',0.03,'全聯福利中心',NULL,'nan'),('013','2','104',0.03,'麥當勞、星巴克',NULL,'nan'),('013','2','104',0.03,'foodomo',NULL,'nan'),('013','2','104',0.03,'遠東SOGO百貨',NULL,'nan'),('013','2','104',0.03,'博客來',NULL,'nan'),('013','2','104',0.03,'OPEN錢包',NULL,'nan'),('013','2','105',0.003,'LinePay',NULL,'nan'),('013','2','105',0.035,'遠東SOGO百貨 太平洋百貨 廣三SOGO',NULL,'11-12月壽星'),('013','2','105',0.035,'民宿、青年旅館、連鎖飯店',NULL,'nan'),('013','2','105',0.1,'茹絲葵經典牛排館台灣(Ruth\'s Chris Steak House)\nUmai屋馬燒肉\nsolo pasta 義大利麵\n俺達の肉屋 日本和牛專門店\n鹽之華法式餐廳Fleur de Sel Restaurant\n廚房有雞花雕雞\n碳佐麻里精品燒肉\n与玥樓頂級粵菜餐廳\nRAW\n山海樓\n金蓬萊遵古台菜餐廳\n老新台菜',NULL,'nan'),('013','2','105',0.1,'國賓影城\n威秀影城\nShowTimes 秀泰影城',NULL,'nan'),('013','2','105',0.1,'錢櫃KTV\n好樂迪KTV\n星聚點KTV\n享溫馨KTV',NULL,'nan'),('013','1','002',0.005,'LinePay',NULL,'nan'),('013','1','002',0.001,'蝦皮購物',NULL,'nan'),('013','1','002',0.002,'蝦皮商城',NULL,'nan'),('013','1','003',0,'LinePay',NULL,'新用戶刷卡禮15萬5000點'),('013','0','004',0.005,'LinePay',NULL,'nan'),('013','1','005',0.005,'LinePay',NULL,'加油金'),('013','1','005',0.01,'台塑',NULL,'加油金'),('013','2','005',0.005,'LinePay',NULL,'加油金'),('013','2','005',0.01,'台塑',NULL,'加油金'),('013','1','006',0.003,'台塑生醫實體直營門市、長庚生技實體直營門市、台塑購物網、台塑網旅行社',NULL,'nan'),('013','1','007',0.003,'LinePay',NULL,'nan'),('013','1','008',0.003,'LinePay',NULL,'nan');
/*!40000 ALTER TABLE `basic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 14:12:11
